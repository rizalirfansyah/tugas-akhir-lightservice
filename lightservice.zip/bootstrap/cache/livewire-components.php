<?php return array (
  'user-edit' => 'App\\Http\\Livewire\\UserEdit',
);