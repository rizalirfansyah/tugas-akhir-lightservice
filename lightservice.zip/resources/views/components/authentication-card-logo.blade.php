<a href="/">
    <img src="img/logoweb.png" alt="" class="w-36">
</a>
